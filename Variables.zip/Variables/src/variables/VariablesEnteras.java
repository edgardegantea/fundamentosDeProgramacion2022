package variables;
import java.util.Scanner;

public class VariablesEnteras {
    
    public void enteros() {
        int x;  // Inicialización de variable x de tipo entero (int)
        x = 5;  // Asignación del valor a x
        
        int y = 10;  // Declaración e inicialización de variable 'y' entera
        var z = 20;
        
        // System.out.println("Valor de x es " + x);
        
        x = 7;
        // System.out.println("Ahora el valor de x es " + x);
        System.out.println("x = " + x
                + "\ny = " + y
                + "\nz = " + z);
    }
    
    
    public void suma() {
        Scanner entrada = new Scanner(System.in);
        
        int a = 0;
        int b = 0;

        System.out.println("Este programa suma dos números enteros"
                + "\nIngresa el primer número: ");
        a = entrada.nextInt();
        
        System.out.println("Ingresa el segundo número: ");
        b = entrada.nextInt();
       
        int suma = a + b;
        
        System.out.println("Suma= " + suma);
    }
    
    
    public void resta () {
        
    }
    
    
    public void division () {
        
    }
    
    
    public void multiplicacion () {
        
    }
    
}
