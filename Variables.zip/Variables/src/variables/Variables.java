package variables;

/**
 * @author Edgar Degante
 */
public class Variables {
    
    public static void main(String[] args) {
        VariablesEnteras ve = new VariablesEnteras();
        // ve.enteros();
        ve.suma();
    }
    
}
